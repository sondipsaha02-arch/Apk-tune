import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.sondipsaha.tune',
  appName: 'Tune',
  webDir: 'dist',
  android: {
    backgroundColor: '#06060a'
  }
};

export default config;
