# Tune Android APK build

This project is prepared for GitHub Actions + Capacitor Android.

## GitHub
1. Upload the contents of this folder to the repository root (not the outer folder).
2. Go to Actions -> Build Tune APK -> Run workflow.
3. When the workflow finishes, open the run and download the `Tune-APK` artifact.

## Backend URL
The Android app needs the Tune Node/WebSocket backend online. In GitHub:
Settings -> Secrets and variables -> Actions -> Variables -> New repository variable

Name: `TUNE_SERVER_URL`
Value: your HTTPS Tune backend URL, for example `https://your-tune-server.example.com`

The app also accepts a saved `tune_server_url` value in localStorage for advanced use.

## Gemini API key
The app keeps the user's Gemini API key in localStorage and sends it to the backend for Live sessions and screen analysis. Do not commit a Gemini API key to GitHub.
