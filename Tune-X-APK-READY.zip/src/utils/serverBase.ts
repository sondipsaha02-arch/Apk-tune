/**
 * Returns the backend origin used by Tune.
 * - On normal web hosting, same-origin requests are used.
 * - On the Android APK, VITE_TUNE_SERVER_URL (or a saved local URL) can point
 *   to the deployed Tune backend.
 */
export function getServerBaseUrl(): string {
  const saved = typeof window !== 'undefined' ? localStorage.getItem('tune_server_url') : '';
  const configured = (saved || import.meta.env.VITE_TUNE_SERVER_URL || '').trim();
  return configured.replace(/\/$/, '');
}

export function apiUrl(path: string): string {
  const base = getServerBaseUrl();
  if (!base) return path;
  return `${base}${path.startsWith('/') ? path : `/${path}`}`;
}

export function websocketUrl(path = '/ws'): string {
  const base = getServerBaseUrl();
  if (base) {
    const url = new URL(base);
    url.protocol = url.protocol === 'https:' ? 'wss:' : 'ws:';
    url.pathname = path;
    url.search = '';
    url.hash = '';
    return url.toString();
  }

  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  return `${protocol}//${window.location.host}${path}`;
}
